package com.discover.demo.controller;

import com.discover.demo.entity.EmployeeEntity;
import com.discover.demo.model.EmployeeModel;
import com.discover.demo.service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/employee")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping(path = "/{empId}")
    public ResponseEntity<EmployeeModel> getEmployeeDetails(@PathVariable("empId") Long empId) {
        return new ResponseEntity<>(employeeService.getEmployeeEntity(empId), HttpStatus.OK);
    }

    @PostMapping(path = "/")
    public ResponseEntity<EmployeeModel> getEmployeeDetails(@RequestBody EmployeeModel employeeModel) {
        return new ResponseEntity<>(employeeService.upsertEmployeeEntity(employeeModel), HttpStatus.OK);
    }

    @DeleteMapping(path = "/{empId}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable("empId") Long empId) {
        employeeService.deleteEmployeeEntity(empId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @GetMapping(path = "/")
    public ResponseEntity<List<EmployeeModel>> getAllEmployeeEntries() {
        return new ResponseEntity<>(employeeService.getAllEmployeeEntities(), HttpStatus.OK);
    }
}