package com.discover.demo.controller;

import com.discover.demo.entity.EmployeeEntity;
import com.discover.demo.service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/v1/employee")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping(path = "/{empId}")
    public ResponseEntity<EmployeeEntity> getEmployeeDetails(@PathVariable("empId") Long empId) {
        return new ResponseEntity<>(employeeService.getEmployeeEntity(empId), HttpStatus.OK);
    }

    @PostMapping(path = "/")
    public ResponseEntity<EmployeeEntity> getEmployeeDetails(@RequestBody EmployeeEntity employeeEntity) {
        return new ResponseEntity<>(employeeService.upsertEmployeeEntity(employeeEntity), HttpStatus.OK);
    }

    @DeleteMapping(path = "/{empId}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable("empId") Long empId) {
        employeeService.deleteEmployeeEntity(empId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}