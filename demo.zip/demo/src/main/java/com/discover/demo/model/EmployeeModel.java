package com.discover.demo.model;

import lombok.Data;

@Data
public class EmployeeModel {
    private Long empId;
    private String empName;
    private String empAddress;
}
