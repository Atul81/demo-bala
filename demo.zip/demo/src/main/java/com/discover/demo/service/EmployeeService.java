package com.discover.demo.service;

import com.discover.demo.entity.EmployeeEntity;
import com.discover.demo.model.EmployeeModel;
import com.discover.demo.repository.EmployeeRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public EmployeeModel upsertEmployeeEntity(EmployeeModel employeeModel) {
        EmployeeEntity employeeEntity = new EmployeeEntity();
        if (employeeModel.getEmpId() == null) {
            employeeEntity.setCreatedAt(Timestamp.from(Instant.now()));
            BeanUtils.copyProperties(employeeModel, employeeEntity, "empId");
        } else {
            EmployeeEntity employeeEntityExisting = employeeRepository.findById(employeeModel.getEmpId())
                    .orElseThrow(() -> new IllegalArgumentException("Id Not Found"));
            employeeEntity.setEmpAddress(employeeModel.getEmpAddress());
            employeeEntity.setEmpId(employeeEntityExisting.getEmpId());
            employeeEntity.setCreatedAt(employeeEntityExisting.getCreatedAt());
            employeeEntity.setEmpName(employeeModel.getEmpName());
        }
        employeeEntity.setUpdatedAt(Timestamp.from(Instant.now()));
        employeeEntity = employeeRepository.save(employeeEntity);
        BeanUtils.copyProperties(employeeEntity, employeeModel);
        return employeeModel;
    }

    public EmployeeModel getEmployeeEntity(Long empId) {
        EmployeeEntity employeeEntity = employeeRepository.findById(empId).orElseThrow();
        EmployeeModel employeeModel = new EmployeeModel();
        BeanUtils.copyProperties(employeeEntity, employeeModel);
        return employeeModel;
    }

    public void deleteEmployeeEntity(Long empId) {
        EmployeeEntity employeeEntity = employeeRepository.findById(empId).orElseThrow(() -> new IllegalArgumentException("Id Not Found"));
        employeeRepository.delete(employeeEntity);
    }

    public List<EmployeeModel> getAllEmployeeEntities() {
        return employeeRepository.findAll().stream().map(employeeEntity -> {
            EmployeeModel employeeModel = new EmployeeModel();
            BeanUtils.copyProperties(employeeEntity, employeeModel);
            return employeeModel;
        }).collect(Collectors.toList());
    }
}