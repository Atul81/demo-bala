package com.discover.demo.service;

import com.discover.demo.entity.EmployeeEntity;
import com.discover.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public EmployeeEntity upsertEmployeeEntity(EmployeeEntity employeeEntity) {
        return employeeRepository.save(employeeEntity);
    }

    public EmployeeEntity getEmployeeEntity(Long empId) {
        return employeeRepository.findById(empId).orElseThrow();
    }

    public void deleteEmployeeEntity(Long empId) {
        employeeRepository.findById(empId).ifPresent(employeeRepository::delete);
    }
}