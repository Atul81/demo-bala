package com.discover.demo.service;

import com.discover.demo.model.EmployeeModel;
import com.discover.demo.repository.EmployeeRepository;
import com.discover.demo.utils.MockEmployee;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class EmployeeServiceTest {

    @InjectMocks
    private EmployeeService employeeService;

    @Mock
    private EmployeeRepository employeeRepository;

    @Test
    void createEmployeeEntity() {
        Mockito.when(employeeRepository.save(Mockito.any())).thenReturn(MockEmployee.employeeEntityWithEmpId());
        employeeService.upsertEmployeeEntity(MockEmployee.employeeModelNoEmpId());
    }
    @Test
    void createEmployeeEntity_Exception() {
        try {
            Mockito.when(employeeRepository.save(Mockito.any())).thenThrow(new IllegalArgumentException("Id not found"));
            employeeService.upsertEmployeeEntity(MockEmployee.employeeModelNoEmpId());
        } catch (Exception e) {
            // error handling
        }
    }


    @Test
    void updateEmployeeEntity() {
        Mockito.when(employeeRepository.findById(1L)).thenReturn(Optional.of(MockEmployee.employeeEntityWithEmpId()));
        Mockito.when(employeeRepository.save(Mockito.any())).thenReturn(MockEmployee.employeeEntityWithEmpId());
        employeeService.upsertEmployeeEntity(MockEmployee.employeeModelWithEmpId());
    }

    @Test
    void getEmployeeEntity() {
        Mockito.when(employeeRepository.findById(1L)).thenReturn(Optional.of(MockEmployee.employeeEntityWithEmpId()));
        EmployeeModel employeeEntity = employeeService.getEmployeeEntity(1L);
        Assertions.assertEquals(1L, employeeEntity.getEmpId());
    }

    @Test
    void deleteEmployeeEntity() {
        Mockito.when(employeeRepository.findById(1L)).thenReturn(Optional.of(MockEmployee.employeeEntityWithEmpId()));
        employeeService.deleteEmployeeEntity(1L);
    }

    @Test
    void getAllEmployeeEntities() {
        Mockito.when(employeeRepository.findAll()).thenReturn(List.of(MockEmployee.employeeEntityWithEmpId()));
        List<EmployeeModel> allEmployeeEntities = employeeService.getAllEmployeeEntities();
        Assertions.assertEquals(1, allEmployeeEntities.size());
    }
}