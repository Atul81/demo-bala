package com.discover.demo.utils;

import com.discover.demo.entity.EmployeeEntity;
import com.discover.demo.model.EmployeeModel;

import java.sql.Timestamp;
import java.time.Instant;

public class MockEmployee {

    public static EmployeeModel employeeModelWithEmpId() {
        EmployeeModel employeeModel = new EmployeeModel();
        employeeModel.setEmpAddress("test");
        employeeModel.setEmpName("test");
        employeeModel.setEmpId(1L);
        return employeeModel;
    }

    public static EmployeeModel employeeModelNoEmpId() {
        EmployeeModel employeeModel = new EmployeeModel();
        employeeModel.setEmpAddress("test");
        employeeModel.setEmpName("test");
        return employeeModel;
    }

    public static EmployeeEntity employeeEntityWithEmpId() {
        EmployeeEntity employeeEntity = new EmployeeEntity();
        employeeEntity.setEmpAddress("test");
        employeeEntity.setEmpName("test");
        employeeEntity.setEmpId(1L);
        employeeEntity.setCreatedAt(Timestamp.from(Instant.now()));
        employeeEntity.setUpdatedAt(Timestamp.from(Instant.now()));
        return employeeEntity;
    }

    public static EmployeeEntity employeeEntityNoEmpId() {
        EmployeeEntity employeeEntity = new EmployeeEntity();
        employeeEntity.setEmpAddress("test");
        employeeEntity.setEmpName("test");
        employeeEntity.setEmpId(0L);
        employeeEntity.setCreatedAt(Timestamp.from(Instant.now()));
        employeeEntity.setUpdatedAt(Timestamp.from(Instant.now()));
        return employeeEntity;
    }

}
